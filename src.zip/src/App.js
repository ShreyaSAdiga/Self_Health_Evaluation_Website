/*import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;
*/
import React from 'react';
import ReactDOM from "react-dom";
import './App.css';
import Navbar from './components/Navbar';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/index';
import About from './pages/about';
import Events from './pages/events';
import AnnualReport from './pages/annual';
import Teams from './pages/team';
import Blogs from './pages/blogs';
import SignUp from './pages/signup';

export default function App() {
  return (
  	<Router>
  	  <Navbar />
  	  <Routes>
        
  	  	<Route path='/' exact element={<Home/>} />
  	  	<Route path='/about' element={<About/>} />
  	  	<Route path='/events' element={<Events/>} />
  	  	<Route path='/annual' element={<AnnualReport/>} />
  	  	<Route path='/team' element={<Teams/>} />
  	  	<Route path='/blogs' element={<Blogs/>} />
  	  	<Route path='/sign-up' element={<SignUp/>} />
        
        {/*
  	  	<Route exact path='/'><Home/> </Route>
  	  	<Route path='/about'><About/> </Route>
  	  	<Route path='/events'><Events/> </Route>
  	  	<Route path='/annual'><AnnualReport/> </Route>
  	  	<Route path='/team'><Teams/> </Route>
  	  	<Route path='/blogs'><Blogs/> </Route>
  	  	<Route path='/sign-up'><SignUp/> </Route>
        */}
        
  	  </Routes>
  	</Router>
  );
}

// export default App;
ReactDOM.render(<App />, document.getElementById("root"));

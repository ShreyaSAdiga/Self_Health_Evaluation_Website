/*import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
*/
import React from 'react';
const Home = () => {
	const style_name={fontstyle:"bold",fontFamily:"cursive",fontSize:"50px",margin:"20px"};
	const styleImg={height:"200px", width:"200px",margin:"100px"}
	return (
		<span style={{float:"left",background:"pink",margin:"100px",border:"dotted"}}>

		<h3 style={style_name}>HEALTH EVAL</h3>
		<img src="logo.jpeg" style={styleImg}/>
		</span>
	);
};

{/*
class Home extends React.Component
{
	render()
	{
		return (
			<div
			style={{
				display: 'flex',
				justifyContent: 'Right',
				alignItems: 'Right',
				height: '100vh'
			}}
			>
			<h1>Welcome to GeeksforGeeks</h1>
			</div>
		);
	}
}
*/}
export default Home;
